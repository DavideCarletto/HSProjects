package Articoli;

public class NessunContenutoExcpetion extends Exception{

	
	public NessunContenutoExcpetion(String msg) {
		
		super(msg);
	}
}
