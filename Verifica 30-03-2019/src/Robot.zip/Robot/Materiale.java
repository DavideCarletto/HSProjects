package Robot;

public enum Materiale {

	ACCIAIO,
	ALLUMINIO,
	FERRO,
}
