package liceocuneo.NXT;

public enum Porta {

	PORTA_A,
	PORTA_B,
	PORTA_C
}
