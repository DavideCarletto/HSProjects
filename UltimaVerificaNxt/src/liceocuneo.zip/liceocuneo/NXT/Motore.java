package liceocuneo.NXT;

public class Motore {

	private Porta porta;

	public Motore(Porta porta) {
		super();
		this.porta = porta;
	}
	
	
}
