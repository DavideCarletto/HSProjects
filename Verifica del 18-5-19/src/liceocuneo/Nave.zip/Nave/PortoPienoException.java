package liceocuneo.Nave;

public class PortoPienoException extends Exception {

	public PortoPienoException(String msg) {
		super(msg);
	}
}
