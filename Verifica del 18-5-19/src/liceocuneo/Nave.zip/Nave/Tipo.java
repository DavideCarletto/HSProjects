package liceocuneo.Nave;

public enum Tipo {

	PASSEGGERI,
	MERCI,
}
