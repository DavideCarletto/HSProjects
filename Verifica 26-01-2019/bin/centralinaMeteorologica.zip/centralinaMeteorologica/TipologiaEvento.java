package centralinaMeteorologica;

public enum TipologiaEvento {
	 VENTO,
	 UMIDITA,
	 TEMPERATURA,
	 RADIZIONE_UV
}
