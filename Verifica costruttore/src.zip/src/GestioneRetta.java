
public class GestioneRetta {

	public static void main(String[]args) {
			Punto p1 = new Punto(5,7);
			Retta r1 = new Retta(8,6);
	}
}
