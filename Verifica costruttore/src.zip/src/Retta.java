
public class Retta {
		
		private int m;
		private int q;
		
		public Retta(int m, int q) {
			this.m = m;
			this.q = q;
		}
}
